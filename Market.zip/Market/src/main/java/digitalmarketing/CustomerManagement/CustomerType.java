package digitalmarketing.CustomerManagement;


import java.io.Serializable;
import java.util.Objects;

public class CustomerType implements Serializable {
    /**
     * education discount: 0.7
     * enterprise discount: 0.8
     * personal : no discount
     */

    private String type;
    private double discount;


    public CustomerType(String type, double discount) {
        this.type = type;
        this.discount = discount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomerType that = (CustomerType) o;
        return Double.compare(that.discount, discount) == 0 && Objects.equals(type, that.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, discount);
    }

    @Override
    public String toString() {
        return "CustomerType{" +
                "type='" + type + '\'' +
                ", discount=" + discount +
                '}';
    }
}
