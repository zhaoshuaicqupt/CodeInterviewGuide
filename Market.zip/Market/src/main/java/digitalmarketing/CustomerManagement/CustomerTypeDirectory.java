package digitalmarketing.CustomerManagement;

import digitalmarketing.CustomerManagement.CustomerType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CustomerTypeDirectory implements Serializable {
    List<CustomerType> customerTypeList;

    public CustomerTypeDirectory() {
        this.customerTypeList = new ArrayList<>();
    }

    public CustomerType newCustomerType(String type, double discount) {
        CustomerType customerType = new CustomerType(type, discount);
        customerTypeList.add(customerType);
        return customerType;
    }

    public CustomerType obtainCustomerType(String typeName) {
        for (CustomerType customerType : customerTypeList) {
            if (customerType.getType().equals(typeName)) {
                return customerType;
            }
        }
        return null;
    }

    public List<CustomerType> getCustomerTypeList() {
        return customerTypeList;
    }

    public void setCustomerTypeList(List<CustomerType> customerTypeList) {
        this.customerTypeList = customerTypeList;
    }

    @Override
    public String toString() {
        return "CustomerTypeDirectory{" +
                "customerTypeList=" + customerTypeList +
                '}';
    }
}
