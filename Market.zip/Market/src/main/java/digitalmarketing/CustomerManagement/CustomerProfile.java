/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.CustomerManagement;

import digitalmarketing.OrderManagement.Order;
import digitalmarketing.Personnel.Person;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author kal bugrara
 */
public class CustomerProfile implements Serializable {
    ArrayList<Order> orders;
    Person person;
    CustomerType customerType;


    public CustomerProfile(Person p, CustomerType customerType) {
        person = p;
        orders = new ArrayList();
        this.customerType = customerType;
    }


    /**
     * for each order in the customer orderlist
     * calculate order price performance and add it to the sum
     *
     * @return
     */
    public int obtainTotalPricePerformance() {
        int totalPerformance = 0;
        for (Order order : orders) {
            totalPerformance += order.obtainOrderPricePerformance();
        }
        return totalPerformance;
    }

    /**
     * for each order in the customer order list
     * calculate if order is positive (actual order total is greater than sum of item targets
     * if yes then add 1 to total
     *
     * @return
     */
    public int obtainNumberOfOrdersAboveTotalTarget() {
        int sum = 0;
        for (Order o : orders) {
            if (o.isOrderAboveTotalTarget() == true) sum = sum + 1;
        }

        return sum;
    }

    /**
     * for each order in the customer order list
     * calculate if order is negative
     * if yes then add 1 to total
     *
     * @return
     */
    public int obtainNumberOfOrdersBelowTotalTarget() {
        int sum = 0;
        for (Order o : orders) {
            if (o.obtainOrderPricePerformance() < 0) {
                sum += 1;
            }
        }
        return sum;
    }

    public boolean isMatch(String id) {
        return person.getId().equals(id);
    }

    public void addCustomerOrder(Order o) {
        orders.add(o);
    }

    public String obtainPersonId() {
        return person.getId();
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }

    public void setOrders(ArrayList<Order> orders) {
        this.orders = orders;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    @Override
    public String toString() {
        return "CustomerProfile{" +
                "orders=" + orders +
                ", person=" + person +
                ", customerType=" + customerType +
                '}';
    }
}
