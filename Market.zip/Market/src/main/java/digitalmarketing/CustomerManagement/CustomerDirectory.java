/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.CustomerManagement;

import digitalmarketing.Personnel.Person;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

/**
 * @author kal bugrara
 */
public class CustomerDirectory implements Serializable {

    ArrayList<CustomerProfile> customerlist;

    public CustomerDirectory() {

        customerlist = new ArrayList();

    }

    public CustomerProfile newCustomerProfile(Person p, CustomerType type) {

        CustomerProfile sp = new CustomerProfile(p, type);
        customerlist.add(sp);
        return sp;
    }

    public CustomerProfile findCustomer(String id) {

        for (CustomerProfile sp : customerlist) {

            if (sp.isMatch(id)) {
                return sp;
            }
        }
        return null; //not found after going through the whole list
    }

    public CustomerProfile findCustomerByIndex(int index) {
        if (index < 0) return null;
        if (index > customerlist.size()) return null;
        return customerlist.get(index);
    }

    public void printCustomerNames() {

        Collections.sort(customerlist, new CustomerComparator());


        for (CustomerProfile c : customerlist) {
            System.out.println(c.obtainPersonId());
        }
    }

    public ArrayList<CustomerProfile> getCustomerlist() {
        return customerlist;
    }

    public void setCustomerlist(ArrayList<CustomerProfile> customerlist) {
        this.customerlist = customerlist;
    }

    @Override
    public String toString() {
        return "CustomerDirectory{" +
                "customerlist=" + customerlist +
                '}';
    }
}
