/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.OrderManagement;

import digitalmarketing.CustomerManagement.CustomerProfile;
import digitalmarketing.MarketModel.MarketChannelAssignment;
import digitalmarketing.ProductManagement.SolutionOffer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author kal bugrara
 */
public class Order implements Serializable {

    CustomerProfile customer;
    List<OrderItem> orderItems;
    MarketChannelAssignment assignment;

    public Order(CustomerProfile customer,MarketChannelAssignment assignment) {
        orderItems = new ArrayList();
        this.customer = customer;
        this.assignment = assignment;
        customer.addCustomerOrder(this); //we link the order to the customer
    }

    public OrderItem newOrderItem(SolutionOffer solutionOffer, int quantity) {
        OrderItem oi = new OrderItem(solutionOffer, quantity);
        orderItems.add(oi);
        return oi;
    }

    public int obtainOrderTotal() {
        int sum = 0;
        for (OrderItem oi : orderItems) {
            sum = sum + oi.obtainOrderItemTotal();
        }
        return sum;
    }

    public double ObtainOrderActualTotal() {
        double sum = 0;
        double marketDiscount = assignment.getMarket().getMarketDiscount();
        double channelDiscount = assignment.getChannel().getChannelDiscount();
        for(OrderItem oi :orderItems) {
            sum += oi.obtainOrderItemTotal() * marketDiscount * channelDiscount;
        }
        return sum;
    }

    public int obtainOrderPricePerformance() {
        int sum = 0;
        for (OrderItem oi : orderItems) {
            sum = sum + oi.calculatePricePerformance();     //positive and negative values       
        }
        return sum;
    }

    public int obtainNumberOfOrderItemsAboveTarget() {
        int sum = 0;
        for (OrderItem oi : orderItems) {
            if (oi.isActualAboveTarget() == true) {
                sum = sum + 1;
            }
        }
        return sum;
    }

    //sum all the item targets and compare to the total of the order 
    public boolean isOrderAboveTotalTarget() {
        int sum = 0;
        for (OrderItem oi : orderItems) {
            sum = sum + oi.obtainOrderItemTargetTotal(); //product targets are added
        }
        if (obtainOrderTotal() > sum) {
            return true;
        } else {
            return false;
        }
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public CustomerProfile getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerProfile customer) {
        this.customer = customer;
    }

    public MarketChannelAssignment getAssignment() {
        return assignment;
    }

    public void setAssignment(MarketChannelAssignment assignment) {
        this.assignment = assignment;
    }

    public void printOrderDetails() {
        System.out.println("Order for " + customer.obtainPersonId());
        for (OrderItem oi : orderItems) {
            oi.printItemDetails();
        }
    }

    @Override
    public String toString() {
        return "Order{" +
                "customer=" + customer +
                ", orderItems=" + orderItems +
                ", assignment=" + assignment +
                '}';
    }
}
