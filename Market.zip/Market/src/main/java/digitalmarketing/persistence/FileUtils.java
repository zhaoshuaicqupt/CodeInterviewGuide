package digitalmarketing.persistence;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileUtils {
    public static void saveObjToFile(Object obj, String filePath) {
        try {
            ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(filePath));
            outputStream.writeObject(obj);
            outputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static <T> T getObjectFromFile(String filePath) {
        T business = null;
        try {
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filePath));
            business = (T) inputStream.readObject();
            return business;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return business;
        }
    }
}
