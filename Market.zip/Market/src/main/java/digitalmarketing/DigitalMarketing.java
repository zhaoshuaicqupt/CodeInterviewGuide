/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing;


import digitalmarketing.Business.Business;
import digitalmarketing.CustomerManagement.CustomerType;
import digitalmarketing.MarketModel.Ads;
import digitalmarketing.MarketModel.Channel;
import digitalmarketing.MarketModel.Market;
import digitalmarketing.Personnel.Person;
import digitalmarketing.ProductManagement.Product;
import digitalmarketing.ProductManagement.SolutionOffer;
import digitalmarketing.Supplier.Supplier;
import digitalmarketing.persistence.FileUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author kal bugrara
 */
public class DigitalMarketing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Business walmart = new Business("Walmart Inc.");
        // init supplierDirectory
        walmart.getSuppliers().newSupplier("apple", "cellular phone");
        walmart.getSuppliers().newSupplier("xiaomi", "cellular phone");
        walmart.getSuppliers().newSupplier("Samsung", "cellular phone");

        // init customerDirectory
        walmart.getCustomers().newCustomerProfile(new Person("alice"), new CustomerType("education", 0.7));
        walmart.getCustomers().newCustomerProfile(new Person("bob"), new CustomerType("personal", 1));
        walmart.getCustomers().newCustomerProfile(new Person("tom"), new CustomerType("enterprise", 0.9));

        // init product
        Supplier apple = walmart.getSuppliers().findSupplier("apple");
        apple.newProduct(1000, 1500, 1300, "iphone12");
        apple.newProduct(1200, 1600, 1400, "iphone13");
        List<Product> products = new ArrayList<>();
        products.add(apple.getProductcatalog().obtainProductByName("iphone12"));
        products.add(apple.getProductcatalog().obtainProductByName("iphone13"));
        // init ads
        Ads advertise_on_youTube = new Ads("Advertise on YouTube", 1300);
        Ads advertise_on_twitter = new Ads("Advertise on twitter", 1500);
        List<Ads> adsList = new ArrayList<>();
        adsList.add(advertise_on_youTube);
        adsList.add(advertise_on_twitter);
        //init channel
        Channel online = new Channel("online", 0.98);
        //init market
        Market ukMarket = new Market("ukMarket", 1.3);
        //init SolutionOffer
        SolutionOffer solutionOffer = new SolutionOffer(products, 1499, "Package A");


        FileUtils.saveObjToFile(walmart, "./data/walmart.bk");
        Business businessRead = FileUtils.getObjectFromFile("./data/walmart.bk");
        System.out.println(businessRead);
    }
}
