package digitalmarketing.MarketModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ChannelDirectory implements Serializable {
    List<Channel> channelList;

    public ChannelDirectory() {
        channelList = new ArrayList<>();
    }

    public Channel newChannel(String channelName, double channelDiscount) {
        Channel channel = new Channel(channelName, channelDiscount);
        channelList.add(channel);
        return channel;
    }

    public void printDetails() {
        System.out.println("Product Catalog");
        for (Channel channel : channelList) {
            System.out.println(channel);
        }
    }

    public Channel ObtainChannnelByName(String name) {
        for (Channel channel : channelList) {
            if (channel.getChannelName().equals(name)) {
                return channel;
            }
        }
        return null;
    }

    public List<Channel> getChannelList() {
        return channelList;
    }

    public void setChannelList(List<Channel> channelList) {
        this.channelList = channelList;
    }

    @Override
    public String toString() {
        return "ChannelDirectory{" +
                "channelList=" + channelList +
                '}';
    }
}
