package digitalmarketing.MarketModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MarketDirectory implements Serializable {
    List<Market> marketList;

    public MarketDirectory() {
        marketList = new ArrayList<>();
    }

    public Market newMarket(String marketName, Double marketDiscount) {
        Market market = new Market(marketName, marketDiscount);
        marketList.add(market);
        return market;
    }

    public Market obatinMarketByName(String name) {
        for (Market market : marketList) {
            if (market.getMarketName().equals(name)) {
                return market;
            }
        }
        return null;
    }

    public void printDetails() {
        System.out.println(" Market catalog");
        for (Market market : marketList) {
            System.out.println(market);
        }
    }

    public List<Market> getMarketList() {
        return marketList;
    }

    public void setMarketList(List<Market> marketList) {
        this.marketList = marketList;
    }

    @Override
    public String toString() {
        return "MarketDirectory{" +
                "marketList=" + marketList +
                '}';
    }
}
