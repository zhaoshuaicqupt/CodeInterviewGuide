/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.MarketModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author kal bugrara
 */
public class Market implements Serializable {
    String marketName;
    Double marketDiscount;
    List<MarketChannelAssignment> channels;

    public Market(String marketName, Double marketDiscount) {
        this.marketName = marketName;
        this.marketDiscount = marketDiscount;
        this.channels = new ArrayList<>();
    }

    /**
     * Add channels to the market
     *
     * @param channel
     */
    public void addChannel(Channel channel) {
        MarketChannelAssignment marketChannelAssignment = new MarketChannelAssignment(this, channel);
        channels.add(marketChannelAssignment);
    }

    public String getMarketName() {
        return marketName;
    }

    public void setMarketName(String marketName) {
        this.marketName = marketName;
    }

    public Double getMarketDiscount() {
        return marketDiscount;
    }

    public void setMarketDiscount(Double marketDiscount) {
        this.marketDiscount = marketDiscount;
    }

    public List<MarketChannelAssignment> getChannels() {
        return channels;
    }

    public void setChannels(List<MarketChannelAssignment> channels) {
        this.channels = channels;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Market market = (Market) o;
        return marketName.equals(market.marketName) && marketDiscount.equals(market.marketDiscount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(marketName, marketDiscount);
    }

    @Override
    public String toString() {
        return "Market{" +
                "marketName='" + marketName + '\'' +
                ", marketDiscount=" + marketDiscount +
                ", channels=" + channels +
                '}';
    }
}
