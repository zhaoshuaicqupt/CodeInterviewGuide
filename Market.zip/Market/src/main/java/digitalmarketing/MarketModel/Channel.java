/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.MarketModel;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * @author kal bugrara
 */
public class Channel implements Serializable {
    private String channelName;
    private double channelDiscount;


    public Channel(String channelName, double channelDiscount) {
        this.channelName = channelName;
        this.channelDiscount = channelDiscount;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public double getChannelDiscount() {
        return channelDiscount;
    }

    public void setChannelDiscount(double channelDiscount) {
        this.channelDiscount = channelDiscount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Channel channel = (Channel) o;
        return Double.compare(channel.channelDiscount, channelDiscount) == 0 && channelName.equals(channel.channelName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(channelName, channelDiscount);
    }

    @Override
    public String toString() {
        return "Channel{" +
                "channelName='" + channelName + '\'' +
                ", channelDiscount=" + channelDiscount +
                '}';
    }
}
