package digitalmarketing.ProductManagement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SolutionDirectory implements Serializable {
    List<SolutionOffer> solutionDirectoryList;

    public SolutionDirectory() {
        solutionDirectoryList = new ArrayList<>();
    }

    public SolutionOffer newSolution(List<Product> products, int price, String solutionDesc) {
        SolutionOffer solutionOffer = new SolutionOffer(products, price, solutionDesc);
        solutionDirectoryList.add(solutionOffer);
        return solutionOffer;
    }

    public void printDetails() {
        System.out.println("Solution Catalog");
        for (SolutionOffer solutionOffer : solutionDirectoryList) {
            System.out.println(solutionOffer);
        }
    }

    public List<SolutionOffer> obtainSolutionByDesc(String desc) {
        List<SolutionOffer> solutionOffers = new ArrayList<>();
        for (SolutionOffer solutionOffer : solutionDirectoryList) {
            if (solutionOffer.getSolutionDesc().indexOf(desc) != -1) {
                solutionOffers.add(solutionOffer);
            }
        }
        return solutionOffers;
    }

    public List<SolutionOffer> obtainSolutionByRange(int min, int max) {
        List<SolutionOffer> solutionOffers = new ArrayList<>();
        for (SolutionOffer solutionOffer : solutionDirectoryList) {
            if (solutionOffer.getPrice() >= min && solutionOffer.getPrice() <= max) {
                solutionOffers.add(solutionOffer);
            }
        }
        return solutionOffers;
    }
}
