/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.ProductManagement;

import digitalmarketing.MarketModel.Market;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author kal bugrara
 */
public class SolutionOffer implements Serializable {
    int price;
    String solutionDesc;
    List<Product> products;


    public SolutionOffer(List<Product> products, int price, String solutionDesc) {
        this.products = products;
        this.price = price;
        this.solutionDesc = solutionDesc;
    }

    public void addProduct(Product p) {
        products.add(p);
    }


    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int p) {
        price = p;
    }

    public String getSolutionDesc() {
        return solutionDesc;
    }

    public void setSolutionDesc(String solutionDesc) {
        this.solutionDesc = solutionDesc;
    }


    @Override
    public String toString() {
        return "SolutionOffer{" +
                "price=" + price +
                ", solutionDesc='" + solutionDesc + '\'' +
                ", products=" + products +
                '}';
    }
}
