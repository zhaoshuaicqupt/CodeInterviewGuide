package digitalmarketing.report;

import digitalmarketing.MarketModel.Channel;
import digitalmarketing.OrderManagement.Order;

import java.util.List;

public class ChannelSummary {
    private double targetSalesVolume = 0;

    private double actualSalesVolume = 0;

    private Channel channel;

    private List<Order> orderList;

    public ChannelSummary(Channel channel, List<Order> orderList) {
        this.channel = channel;
        this.orderList = orderList;
        for (Order order : orderList) {
            this.targetSalesVolume += order.obtainOrderTotal();
            this.actualSalesVolume += order.ObtainOrderActualTotal();
        }
    }

    public double getTargetSalesVolume() {
        return targetSalesVolume;
    }

    public void setTargetSalesVolume(double targetSalesVolume) {
        this.targetSalesVolume = targetSalesVolume;
    }

    public double getActualSalesVolume() {
        return actualSalesVolume;
    }

    public void setActualSalesVolume(double actualSalesVolume) {
        this.actualSalesVolume = actualSalesVolume;
    }

    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }

    @Override
    public String toString() {
        return "ChannelSummary{" +
                " channel=" + channel +
                ", salesSVolume=" + targetSalesVolume +
                ", actualSalesVolume=" + actualSalesVolume +
                '}';
    }
}
