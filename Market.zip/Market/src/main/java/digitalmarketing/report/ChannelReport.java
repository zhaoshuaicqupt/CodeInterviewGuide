package digitalmarketing.report;

import digitalmarketing.MarketModel.Channel;
import digitalmarketing.OrderManagement.Order;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChannelReport implements Serializable {
    private double targetSalesVolume = 0;

    private double actualSalesVolume = 0;

    private List<ChannelSummary> channelSummaryList;

    private Map<Channel, List<Order>> channelOrderMap;

    public ChannelReport(Map<Channel, List<Order>> channelOrderMap) {
        this.channelOrderMap = channelOrderMap;
        this.channelSummaryList = initChannelSummaryList();
    }

    private List<ChannelSummary> initChannelSummaryList() {
        List<ChannelSummary> channelSummaryList = new ArrayList<>();
        for (Map.Entry<Channel, List<Order>> entry : channelOrderMap.entrySet()) {
            ChannelSummary channelSummary = new ChannelSummary(entry.getKey(), entry.getValue());
            targetSalesVolume += channelSummary.getTargetSalesVolume();
            actualSalesVolume += channelSummary.getActualSalesVolume();
            channelSummaryList.add(channelSummary);
        }
        return channelSummaryList;
    }

    public double getTargetSalesVolume() {
        return targetSalesVolume;
    }

    public void setTargetSalesVolume(double targetSalesVolume) {
        this.targetSalesVolume = targetSalesVolume;
    }

    public double getActualSalesVolume() {
        return actualSalesVolume;
    }

    public void setActualSalesVolume(double actualSalesVolume) {
        this.actualSalesVolume = actualSalesVolume;
    }

    public List<ChannelSummary> getChannelSummaryList() {
        return channelSummaryList;
    }

    public void setChannelSummaryList(List<ChannelSummary> channelSummaryList) {
        this.channelSummaryList = channelSummaryList;
    }

    public Map<Channel, List<Order>> getChannelOrderMap() {
        return channelOrderMap;
    }

    public void setChannelOrderMap(Map<Channel, List<Order>> channelOrderMap) {
        this.channelOrderMap = channelOrderMap;
    }

    @Override
    public String toString() {
        return "ChannelReport{" +
                "targetSalesVolume=" + targetSalesVolume +
                ", actualSalesVolume=" + actualSalesVolume +
                ", channelSummaryList=" + channelSummaryList +
                '}';
    }
}
