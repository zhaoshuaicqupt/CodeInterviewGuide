package digitalmarketing.report;

import digitalmarketing.CustomerManagement.CustomerType;
import digitalmarketing.MarketModel.Channel;
import digitalmarketing.OrderManagement.Order;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CustomerTypeReport implements Serializable {

    private double targetSalesVolume = 0;

    private double actualSalesVolume = 0;

    private List<CustomerTypeSummary> customerTypeSummaryList;

    private Map<CustomerType,List<Order>> customerTypeOrderMap;

    public CustomerTypeReport(Map<CustomerType, List<Order>> customerTypeOrderMap) {
        this.customerTypeOrderMap = customerTypeOrderMap;
        this.customerTypeSummaryList = initCustomerTypeSummaryList();
    }

    private List<CustomerTypeSummary> initCustomerTypeSummaryList() {
        List<ChannelSummary> channelSummaryList = new ArrayList<>();
        for(Map.Entry<CustomerType,List<Order>> entry : customerTypeOrderMap.entrySet()) {
            CustomerTypeSummary customerTypeSummary = new CustomerTypeSummary(entry.getKey(),entry.getValue());
            targetSalesVolume += customerTypeSummary.getTargetSalesVolume();
            actualSalesVolume += customerTypeSummary.getActualSalesVolume();
            customerTypeSummaryList.add(customerTypeSummary);
        }
        return customerTypeSummaryList;
    }

    public double getTargetSalesVolume() {
        return targetSalesVolume;
    }

    public void setTargetSalesVolume(double targetSalesVolume) {
        this.targetSalesVolume = targetSalesVolume;
    }

    public double getActualSalesVolume() {
        return actualSalesVolume;
    }

    public void setActualSalesVolume(double actualSalesVolume) {
        this.actualSalesVolume = actualSalesVolume;
    }

    public List<CustomerTypeSummary> getCustomerTypeSummaryList() {
        return customerTypeSummaryList;
    }

    public void setCustomerTypeSummaryList(List<CustomerTypeSummary> customerTypeSummaryList) {
        this.customerTypeSummaryList = customerTypeSummaryList;
    }

    public Map<CustomerType, List<Order>> getCustomerTypeOrderMap() {
        return customerTypeOrderMap;
    }

    public void setCustomerTypeOrderMap(Map<CustomerType, List<Order>> customerTypeOrderMap) {
        this.customerTypeOrderMap = customerTypeOrderMap;
    }

    @Override
    public String toString() {
        return "CustomerTypeReport{" +
                "targetSalesVolume=" + targetSalesVolume +
                ", actualSalesVolume=" + actualSalesVolume +
                ", customerTypeSummaryList=" + customerTypeSummaryList +
                '}';
    }
}
