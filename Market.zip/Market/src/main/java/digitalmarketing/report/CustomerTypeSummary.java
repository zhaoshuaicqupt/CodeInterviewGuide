package digitalmarketing.report;

import digitalmarketing.CustomerManagement.CustomerType;
import digitalmarketing.OrderManagement.Order;

import java.util.List;

public class CustomerTypeSummary {
    private double targetSalesVolume = 0;

    private double actualSalesVolume = 0;

    private CustomerType customerType;

    private List<Order> orderList;

    public CustomerTypeSummary(CustomerType customerType, List<Order> orderList) {
        this.customerType = customerType;
        this.orderList = orderList;
        for (Order order : orderList) {
            this.targetSalesVolume += order.obtainOrderTotal();
            this.actualSalesVolume += order.ObtainOrderActualTotal();
        }
    }

    public double getTargetSalesVolume() {
        return targetSalesVolume;
    }

    public void setTargetSalesVolume(double targetSalesVolume) {
        this.targetSalesVolume = targetSalesVolume;
    }

    public double getActualSalesVolume() {
        return actualSalesVolume;
    }

    public void setActualSalesVolume(double actualSalesVolume) {
        this.actualSalesVolume = actualSalesVolume;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }

    @Override
    public String toString() {
        return "CustomerTypeSummary{" +
                "customerType=" + customerType +
                ", targetSalesVolume=" + targetSalesVolume +
                ", actualSalesVolume=" + actualSalesVolume +
                '}';
    }
}
