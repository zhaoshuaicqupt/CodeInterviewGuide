package digitalmarketing.report;

import digitalmarketing.MarketModel.Market;
import digitalmarketing.OrderManagement.Order;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MarketReport implements Serializable {
    private double targetSalesVolume = 0;

    private double actualSalesVolume = 0;

    private List<MarketSummary> marketSummaryList;

    private Map<Market, List<Order>> marketOrderMap;

    public MarketReport(Map<Market, List<Order>> marketOrderMap) {
        this.marketOrderMap = marketOrderMap;
        this.marketSummaryList = initMarketSummaryList();
    }

    private List<MarketSummary> initMarketSummaryList() {
        List<MarketSummary> marketSummaryList = new ArrayList<>();
        for (Map.Entry<Market, List<Order>> entry : marketOrderMap.entrySet()) {
            MarketSummary marketSummary = new MarketSummary(entry.getKey(), entry.getValue());
            targetSalesVolume += marketSummary.getTargetSalesVolume();
            targetSalesVolume += marketSummary.getActualSalesVolume();
            marketSummaryList.add(marketSummary);
        }
        return marketSummaryList;
    }

    public double getTargetSalesVolume() {
        return targetSalesVolume;
    }

    public void setTargetSalesVolume(double targetSalesVolume) {
        this.targetSalesVolume = targetSalesVolume;
    }

    public double getActualSalesVolume() {
        return actualSalesVolume;
    }

    public void setActualSalesVolume(double actualSalesVolume) {
        this.actualSalesVolume = actualSalesVolume;
    }

    public List<MarketSummary> getMarketSummaryList() {
        return marketSummaryList;
    }

    public void setMarketSummaryList(List<MarketSummary> marketSummaryList) {
        this.marketSummaryList = marketSummaryList;
    }

    public Map<Market, List<Order>> getMarketOrderMap() {
        return marketOrderMap;
    }

    public void setMarketOrderMap(Map<Market, List<Order>> marketOrderMap) {
        this.marketOrderMap = marketOrderMap;
    }

    @Override
    public String toString() {
        return "MarketReport{" +
                "targetSalesVolume=" + targetSalesVolume +
                ", actualSalesVolume=" + actualSalesVolume +
                ", marketSummaryList=" + marketSummaryList +
                '}';
    }
}
