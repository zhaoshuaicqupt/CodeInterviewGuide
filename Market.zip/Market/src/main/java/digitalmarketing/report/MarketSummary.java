package digitalmarketing.report;

import digitalmarketing.MarketModel.Market;
import digitalmarketing.OrderManagement.Order;

import java.util.List;

public class MarketSummary {

    private double targetSalesVolume = 0;

    private double actualSalesVolume = 0;

    private Market market;

    private List<Order> orderList;

    public MarketSummary(Market market, List<Order> orderList) {
        this.market = market;
        this.orderList = orderList;
        for (Order order : orderList) {
            this.targetSalesVolume += order.obtainOrderTotal();
            this.actualSalesVolume += order.ObtainOrderActualTotal();
        }
    }

    public double getTargetSalesVolume() {
        return targetSalesVolume;
    }

    public void setTargetSalesVolume(double targetSalesVolume) {
        this.targetSalesVolume = targetSalesVolume;
    }

    public double getActualSalesVolume() {
        return actualSalesVolume;
    }

    public void setActualSalesVolume(double actualSalesVolume) {
        this.actualSalesVolume = actualSalesVolume;
    }

    public Market getMarket() {
        return market;
    }

    public void setMarket(Market market) {
        this.market = market;
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }

    @Override
    public String toString() {
        return "MarketSummary{" +
                "market=" + market +
                ", targetSalesVolume=" + targetSalesVolume +
                ", actualSalesVolume=" + actualSalesVolume +
                '}';
    }
}
