/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.Business;

import digitalmarketing.CustomerManagement.CustomerDirectory;
import digitalmarketing.CustomerManagement.CustomerType;
import digitalmarketing.CustomerManagement.CustomerTypeDirectory;
import digitalmarketing.MarketModel.Channel;
import digitalmarketing.MarketModel.ChannelDirectory;
import digitalmarketing.MarketModel.Market;
import digitalmarketing.MarketModel.MarketDirectory;
import digitalmarketing.OrderManagement.MasterOrderList;
import digitalmarketing.OrderManagement.Order;
import digitalmarketing.ProductManagement.SolutionDirectory;
import digitalmarketing.Supplier.SupplierDirectory;
import digitalmarketing.report.ChannelReport;
import digitalmarketing.report.CustomerTypeReport;
import digitalmarketing.report.MarketReport;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author kal bugrara
 */
public class Business implements Serializable {

    String name;
    MasterOrderList masterorderlist;
    SupplierDirectory suppliers;
    CustomerDirectory customers;
    ChannelDirectory channels;
    MarketDirectory markets;
    CustomerTypeDirectory customerTypes;
    SolutionDirectory solutions;

    public Business(String n) {
        name = n;
        masterorderlist = new MasterOrderList();
        suppliers = new SupplierDirectory();
        customers = new CustomerDirectory();
        channels = new ChannelDirectory();
        markets = new MarketDirectory();
        customerTypes = new CustomerTypeDirectory();
        solutions = new SolutionDirectory();
    }

    public ChannelReport generateChannelReport() {
        Map<Channel, List<Order>> channelOrderMap = generateChannelOrderMap();
        return new ChannelReport(channelOrderMap);
    }

    public Map<Channel, List<Order>> generateChannelOrderMap() {
        Map<Channel, List<Order>> channelOrderMap = new LinkedHashMap<>();
        for (Order order : getMasterorderlist().getOrders()) {
            Channel selectChannel = order.getAssignment().getChannel();
            List<Order> orderList = channelOrderMap.get(selectChannel);
            if (null == orderList) {
                orderList = new ArrayList<>();
            }
            orderList.add(order);
        }
        return channelOrderMap;
    }

    public MarketReport generateMarketReport() {
        Map<Market, List<Order>> marketOrderMap = generateMarketOrderMap();
        return new MarketReport(marketOrderMap);

    }

    private Map<Market, List<Order>> generateMarketOrderMap() {
        Map<Market, List<Order>> marketOrderMap = new LinkedHashMap<>();
        for (Order order : getMasterorderlist().getOrders()) {
            Market selectMarket = order.getAssignment().getMarket();
            List<Order> orderList = marketOrderMap.get(selectMarket);
            if (null == orderList) {
                orderList = new ArrayList<>();
            }
            orderList.add(order);
        }
        return marketOrderMap;
    }

    public CustomerTypeReport generateCustomerTypeReport() {
        Map<CustomerType, List<Order>> customerTypeOrderMap = generateCustomerTypeOderMap();
        return new CustomerTypeReport(customerTypeOrderMap);

    }

    private Map<CustomerType, List<Order>> generateCustomerTypeOderMap() {
        Map<CustomerType, List<Order>> customerTypeOrderMap = new LinkedHashMap<>();
        for (Order order : getMasterorderlist().getOrders()) {
            CustomerType customerType = order.getCustomer().getCustomerType();
            List<Order> orderList = customerTypeOrderMap.get(customerType);
            if (null == orderList) {
                orderList = new ArrayList<>();
            }
            orderList.add(order);
        }
        return customerTypeOrderMap;
    }


    private void printTitle() {
        System.out.println("Business : " + name);
    }


    public void printSupplierDetails() {
        printTitle();
        suppliers.printSupplierList();
    }

    public void printAllOrders() {
        printTitle();
        masterorderlist.printOrders();
    }

    public MasterOrderList getMasterorderlist() {
        return masterorderlist;
    }

    public void setMasterorderlist(MasterOrderList masterorderlist) {
        this.masterorderlist = masterorderlist;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SupplierDirectory getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(SupplierDirectory suppliers) {
        this.suppliers = suppliers;
    }

    public CustomerDirectory getCustomers() {
        return customers;
    }

    public void setCustomers(CustomerDirectory customers) {
        this.customers = customers;
    }

    @Override
    public String toString() {
        return "Business{" +
                "name='" + name + '\'' +
                ", masterorderlist=" + masterorderlist +
                ", suppliers=" + suppliers +
                ", customers=" + customers +
                '}';
    }
}
