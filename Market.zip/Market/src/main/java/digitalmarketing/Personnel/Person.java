/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.Personnel;

import java.io.Serializable;

/**
 * @author kal bugrara
 */
public class Person implements Serializable {

    String id;

    public Person(String id) {

        this.id = id;
    }

    public boolean isMatch(String id) {
        if (getId().equals(id)) return true;
        return false;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id='" + id + '\'' +
                '}';
    }
}
