/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing;


import digitalmarketing.Business.Business;
import digitalmarketing.ProductManagement.ProductSummary;
import digitalmarketing.ProductManagement.ProductSummaryComparator;
import digitalmarketing.Supplier.Supplier;
import digitalmarketing.Supplier.SupplierPerformanceComparator;

import java.util.ArrayList;

/**
 * @author kal bugrara
 */
public class DigitalMarketing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here


        Business walmart = new Business("Walmart Inc.");
        DataLoader dataLoader = new DataLoader();

        dataLoader.populateBusiness(walmart);

//        CustomerDirectory cd = walmart.getCustomerDirectory();


        // cd.printCustomerNames();


//       Supplier secondSupplier = walmart.getSupplierDirectory().findSupplierByIndex(1);
//       
//        ProductCatalog pc = secondSupplier.getProductcatalog();
//        
//        pc.newProduct(1, 1, 1, "asa");
//        pc.newProduct(2, 1, 1, "bbn31d2");
//        pc.newProduct(3, 1, 1, "cvvdsd3");
//        pc.newProduct(4, 1, 1, "zzzadsas4");
//        pc.newProduct(5, 1, 1, "xxxdas5");
//        pc.newProduct(6, 1, 1, "yyy11126");
//        
//        pc.printDetails();
//        


//        Scanner sc = new Scanner(System.in);
//        System.out.println("Please choose [1, 2, 3]: ");
//        int choice = sc.nextInt();
//        
//        System.out.println("You picked " + choice);
//        
        ArrayList<Supplier> supplierRank = new ArrayList<Supplier>();
        ArrayList<ProductSummary> productRank = new ArrayList<ProductSummary>();
        for (int i = 0; i < walmart.getSupplierDirectory().getSupplierCount(); i++) {
            Supplier current = walmart.getSupplierDirectory().findSupplierByIndex(i);
            supplierRank.add(current);
            productRank.addAll(walmart.getSupplierPerformanceReport(i).getProductsSummary());
        }
        supplierRank.sort(new SupplierPerformanceComparator());
        productRank.sort(new ProductSummaryComparator());
        System.out.println("---------------Product Rank---------------");
        for (int i = 0; i < 10; i++) {
            productRank.get(i).print();
        }
        System.out.println("---------------Supplier Rank---------------");
        for (int i = 0; i < 3; i++) {
            supplierRank.get(i).printProductSummary();
        }
    }

}
