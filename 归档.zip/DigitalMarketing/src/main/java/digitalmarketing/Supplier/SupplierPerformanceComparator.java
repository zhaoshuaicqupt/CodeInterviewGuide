package digitalmarketing.Supplier;

import java.util.Comparator;

public class SupplierPerformanceComparator implements Comparator<Supplier> {

    public SupplierPerformanceComparator() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public int compare(Supplier o1, Supplier o2) {
        // TODO Auto-generated method stub
        return o2.getProductsReport().getProductSalesValume() - o1.getProductsReport().getProductSalesValume();
    }

}
