/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.ProductManagement;

import java.util.ArrayList;

/**
 *
 * @author kal bugrara
 */
public class ProductsReport {

    ArrayList<ProductSummary> productsummarylist;
    int salesValume;
    int actualSalesValume;

    public ProductsReport() {
        productsummarylist = new ArrayList();
        salesValume=0;
        actualSalesValume=0;
    }

    public void addProductSummary(ProductSummary ps) {

        productsummarylist.add(ps);
        salesValume+=ps.salesvalume;
        actualSalesValume+=ps.acutalsalesvolume;
    }
    
    public int getProductSalesValume() {
    	return salesValume;
    }

    public ProductSummary getTopProductAboveTarget() {
        ProductSummary currenttopproduct = null;

        for (ProductSummary ps : productsummarylist) {
            if (currenttopproduct == null) {
                currenttopproduct = ps; // initial step 
            } else if (ps.getNumberAboveTarget() > currenttopproduct.getNumberAboveTarget()) {
                currenttopproduct = ps; //we have a new higher total
            }

        }
        return currenttopproduct;
    }

    public ArrayList<ProductSummary> getProductsAlwaysAboveTarget() {
        ArrayList<ProductSummary> productsalwaysabovetarget = new ArrayList(); //temp array list

        for (ProductSummary ps : productsummarylist) {
            if (ps.isProductAlwaysAboveTarget() == true) {
                productsalwaysabovetarget.add(ps);
            }
        }

        return productsalwaysabovetarget;
    }
    
    public  ArrayList<ProductSummary> getProductsSummary(){
    	return productsummarylist;
    }
    
    public void print(){
        System.out.println(" -----------  Product Report ----------- ");
        for (ProductSummary ps : productsummarylist){        	
            ps.print();
        }       
    }

    public void printSummary() {
    	 System.out.println(" ----------- Report Summary  ----------- ");
         System.out.println("actualSalesValume:"+  actualSalesValume + " | salesValume: " + salesValume);
    }
}
