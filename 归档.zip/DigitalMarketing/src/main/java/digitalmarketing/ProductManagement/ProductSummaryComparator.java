package digitalmarketing.ProductManagement;

import java.util.Comparator;

public class ProductSummaryComparator implements Comparator<ProductSummary> {

    public ProductSummaryComparator() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public int compare(ProductSummary o1, ProductSummary o2) {
        // TODO Auto-generated method stub

        return o2.salesvalume - o1.salesvalume;
    }

}
