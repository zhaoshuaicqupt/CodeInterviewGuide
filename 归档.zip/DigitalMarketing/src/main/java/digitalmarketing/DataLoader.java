/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package digitalmarketing;

import com.github.javafaker.Faker;
import digitalmarketing.Business.Business;
import digitalmarketing.CustomerManagement.CustomerDirectory;
import digitalmarketing.CustomerManagement.CustomerProfile;
import digitalmarketing.OrderManagement.Order;
import digitalmarketing.Personnel.Person;
import digitalmarketing.ProductManagement.Product;
import digitalmarketing.Supplier.Supplier;
import digitalmarketing.Supplier.SupplierDirectory;

import java.util.Random;

/**
 * @author alelashvili
 */
public class DataLoader {

    Faker faker;


    public DataLoader() {
        faker = new Faker();
    }

    public void populateBusiness(Business b) {
        System.out.println("-----------------populating business:" + b.getName() + "-----------------");
        populateSupplierDirectory(b.getSupplierDirectory(), 30);
        populateCustomerDirectory(b.getCustomerDirectory(), 30);
        // add products

        for (int i = 0; i < 5; i++) {
            generateProduct(b.getSupplierDirectory().findSupplierByIndex(i), 20);
        }

        // add orders
        for (int i = 0; i < 5; i++) {
            generateRandomOrder(b, b.getCustomerDirectory().findCustomerByIndex(i), 3, 5);
        }
        // add

    }


    public void generateRandomOrder(Business b, CustomerProfile customer, int count, int itemCount) {
        // TODO Auto-generated method stub
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            Supplier supplier;
            do {
                supplier = b.getSupplierDirectory().findSupplierByIndex(random.nextInt(b.getSupplierDirectory().getSupplierCount()));
            } while (supplier.getProductcatalog().getProductsCount() < itemCount);

            Order order = b.getMasterorderlist().newOrder(customer);
            for (int j = 0; j < itemCount; j++) {
                Product product = supplier.getProductcatalog().getProductByIndex(random.nextInt(supplier.getProductcatalog().getProductsCount()));
                int quantity = random.nextInt(99) + 1;
                int actualPrice = random.nextInt(product.getCeilingPrice() - product.getFloorPrice()) + product.getFloorPrice();
                order.newOrderItem(product, quantity, actualPrice);
            }
            order.printOrderDetails();
            System.out.println();
        }


    }

    public void populateSupplierDirectory(SupplierDirectory sd, int count) {
        System.out.println("-----------------generating suppliers-----------------");
        for (int i = 0; i < count; i++) {
            String supplierName = faker.company().name();
            sd.newSupplier(supplierName, "General");
            System.out.println("generate supplier:" + supplierName);
        }
    }

    public void populateCustomerDirectory(CustomerDirectory cd, int count) {
        System.out.println("-----------------generating customers-----------------");
        for (int i = 0; i < count; i++) {
            String customerName = faker.name().fullName();
            cd.newCustomerProfile(new Person(customerName));
            System.out.println("generate customer:" + customerName);
        }
    }

    public void generateProduct(Supplier supplier, int count) {
        System.out.println("-----------------generating products-----------------");
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            int l = random.nextInt(999) + 1;
            int u = getRandomPrice(l + 1, l + 201);
            int t = getRandomPrice(l, u);
            Product product = supplier.newProduct(l, u, t, faker.book().title());
            product.printDetails();
        }
    }


    public int getRandomPrice(int lower, int upper) {
        Random random = new Random();
        int result = 0;
        result = lower + random.nextInt(upper - lower);
        return result;
    }


}
