package digitalmarketing.CustomerManagement;

public enum CustomerType {
    EDUCATION("education", 0.7), PERSIONAL("personal", 1), ENTERPRISE("enterprise", 0.9);

    private String type;
    private double discount;

    CustomerType() {
    }

    CustomerType(String type, double discount) {
        this.type = type;
        this.discount = discount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
