/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.Supplier;

import digitalmarketing.ProductManagement.Product;
import digitalmarketing.ProductManagement.ProductCatalog;

import java.io.Serializable;

/**
 * @author kal bugrara
 */
public class Supplier implements Serializable {

    String name;
    ProductCatalog productcatalog;

    public Supplier(String n, String type) {
        name = n;
        productcatalog = new ProductCatalog(type);

    }


    public ProductCatalog getProductcatalog() {
        return productcatalog;
    }

    public void setProductcatalog(ProductCatalog productcatalog) {
        this.productcatalog = productcatalog;
    }
    //add supplier product ..

    //update supplier product ...

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void printSupplierDetails() {
        System.out.println("----------------------------------");
        System.out.println("Supplier : " + name);
        productcatalog.printDetails();
    }

    public Product newProduct(int fp, int cp, int tp, String n) {
        return productcatalog.newProduct(fp, cp, tp, n);
    }

    @Override
    public String toString() {
        return "Supplier{" +
                "name='" + name + '\'' +
                ", productcatalog=" + productcatalog +
                '}';
    }
}

