/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.Supplier;


import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author kal bugrara
 */
public class SupplierDirectory implements Serializable {

    ArrayList<Supplier> suppliers;

    public SupplierDirectory() {
        suppliers = new ArrayList();
    }

    public Supplier newSupplier(String n, String t) {
        Supplier supplier = new Supplier(n, t);
        suppliers.add(supplier);
        return supplier;

    }

    public Supplier findSupplier(String name) {

        for (Supplier supplier : suppliers) {

            if (supplier.getName().equals(name)) {
                return supplier;
            }
        }
        return null;
    }


    public Supplier findSupplierByIndex(int index) {
        if (index < 0) return null;
        if (index > suppliers.size()) return null;
        return suppliers.get(index);
    }

    public void printSupplierList() {
        System.out.println("Supplier List:");
        for (Supplier s : suppliers) {
            s.printSupplierDetails();
        }
    }

    public ArrayList<Supplier> getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(ArrayList<Supplier> suppliers) {
        this.suppliers = suppliers;
    }

    @Override
    public String toString() {
        return "SupplierDirectory{" +
                "suppliers=" + suppliers +
                '}';
    }
}
