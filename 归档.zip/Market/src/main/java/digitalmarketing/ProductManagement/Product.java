/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.ProductManagement;

import digitalmarketing.OrderManagement.OrderItem;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author kal bugrara
 */
public class Product implements Serializable {

    private final String name;
    private int floorPrice;
    private int ceilingPrice;
    private int targetPrice;

    public Product(int fp, int cp, int tp, String n) {
        floorPrice = fp;
        ceilingPrice = cp;
        targetPrice = tp;
        name = n;
    }

    public Product updateProduct(int fp, int cp, int tp) {
        floorPrice = fp;
        ceilingPrice = cp;
        targetPrice = tp;
        return this; //returns itself
    }

    public int getTargetPrice() {
        return targetPrice;
    }

    public void setTargetPrice(int targetPrice) {
        this.targetPrice = targetPrice;
    }

    public int getFloorPrice() {
        return floorPrice;
    }

    public void setFloorPrice(int floorPrice) {
        this.floorPrice = floorPrice;
    }

    public int getCeilingPrice() {
        return ceilingPrice;
    }

    public void setCeilingPrice(int ceilingPrice) {
        this.ceilingPrice = ceilingPrice;
    }

    public String getName() {
        return name;
    }

    public void printDetails() {
        System.out.println("Product: " + name + "| floor: " + floorPrice + "| ceiling: " + ceilingPrice + " target: " + targetPrice);
    }

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", floorPrice=" + floorPrice +
                ", ceilingPrice=" + ceilingPrice +
                ", targetPrice=" + targetPrice +
                '}';
    }
}
