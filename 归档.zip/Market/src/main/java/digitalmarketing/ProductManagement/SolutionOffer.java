/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.ProductManagement;

import digitalmarketing.MarketModel.Market;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author kal bugrara
 */
public class SolutionOffer implements Serializable {
    List<Product> products;
    int price;
    Market market;
    String solutionDesc;

    public SolutionOffer(Market m, String desc) {
        market = m;
        products = new ArrayList();
        this.solutionDesc = desc;
    }

    public SolutionOffer(List<Product> products, int price, Market market, String solutionDesc) {
        this.products = products;
        this.price = price;
        this.market = market;
        this.solutionDesc = solutionDesc;
    }

    public void addProduct(Product p) {
        products.add(p);
    }


    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int p) {
        price = p;
    }

    public Market getMarket() {
        return market;
    }

    public void setMarket(Market market) {
        this.market = market;
    }

    @Override
    public String toString() {
        return "SolutionOffer{" +
                "products=" + products +
                ", price=" + price +
                ", market=" + market +
                ", solutionDesc='" + solutionDesc + '\'' +
                '}';
    }
}
