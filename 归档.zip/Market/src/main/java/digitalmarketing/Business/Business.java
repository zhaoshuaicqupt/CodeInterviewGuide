/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.Business;

import digitalmarketing.CustomerManagement.CustomerDirectory;
import digitalmarketing.OrderManagement.MasterOrderList;
import digitalmarketing.Supplier.SupplierDirectory;

import java.io.Serializable;

/**
 * @author kal bugrara
 */
public class Business implements Serializable {

    String name;
    MasterOrderList masterorderlist;
    SupplierDirectory suppliers;
    CustomerDirectory customers;

    public Business(String n) {
        name = n;
        masterorderlist = new MasterOrderList();
        suppliers = new SupplierDirectory();
        customers = new CustomerDirectory();
    }


    private void printTitle() {
        System.out.println("Business : " + name);
    }


    public void printSupplierDetails() {
        printTitle();
        suppliers.printSupplierList();
    }

    public void printAllOrders() {
        printTitle();
        masterorderlist.printOrders();
    }

    public MasterOrderList getMasterorderlist() {
        return masterorderlist;
    }

    public void setMasterorderlist(MasterOrderList masterorderlist) {
        this.masterorderlist = masterorderlist;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SupplierDirectory getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(SupplierDirectory suppliers) {
        this.suppliers = suppliers;
    }

    public CustomerDirectory getCustomers() {
        return customers;
    }

    public void setCustomers(CustomerDirectory customers) {
        this.customers = customers;
    }

    @Override
    public String toString() {
        return "Business{" +
                "name='" + name + '\'' +
                ", masterorderlist=" + masterorderlist +
                ", suppliers=" + suppliers +
                ", customers=" + customers +
                '}';
    }
}
