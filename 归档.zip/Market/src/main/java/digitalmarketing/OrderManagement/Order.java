/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.OrderManagement;

import digitalmarketing.CustomerManagement.CustomerProfile;
import digitalmarketing.ProductManagement.SolutionOffer;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author kal bugrara
 */
public class Order implements Serializable {

    ArrayList<OrderItem> orderitems;
    CustomerProfile customer;

    public Order() {
    }

    public Order(CustomerProfile cp) {
        orderitems = new ArrayList();
        customer = cp;
        customer.addCustomerOrder(this); //we link the order to the customer
    }


    public OrderItem newOrderItem(SolutionOffer solutionOffer, int quantity) {
        OrderItem oi = new OrderItem(solutionOffer, quantity);
        orderitems.add(oi);
        return oi;
    }

    public int obtainOrderTotal() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.obtainOrderItemTotal();
        }
        return sum;
    }

    public int obtainOrderPricePerformance() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.calculatePricePerformance();     //positive and negative values       
        }
        return sum;
    }

    public int obtainNumberOfOrderItemsAboveTarget() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            if (oi.isActualAboveTarget() == true) {
                sum = sum + 1;
            }
        }
        return sum;
    }

    //sum all the item targets and compare to the total of the order 
    public boolean isOrderAboveTotalTarget() {
        int sum = 0;
        for (OrderItem oi : orderitems) {
            sum = sum + oi.obtainOrderItemTargetTotal(); //product targets are added
        }
        if (obtainOrderTotal() > sum) {
            return true;
        } else {
            return false;
        }
    }

    public ArrayList<OrderItem> getOrderitems() {
        return orderitems;
    }

    public void setOrderitems(ArrayList<OrderItem> orderitems) {
        this.orderitems = orderitems;
    }

    public CustomerProfile getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerProfile customer) {
        this.customer = customer;
    }

    public void printOrderDetails() {
        System.out.println("Order for " + customer.obtainPersonId());
        for (OrderItem oi : orderitems) {
            oi.printItemDetails();
        }
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderitems=" + orderitems +
                ", customer=" + customer +
                '}';
    }
}
