/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.OrderManagement;

import digitalmarketing.ProductManagement.Product;
import digitalmarketing.ProductManagement.SolutionOffer;

import java.io.Serializable;

/**
 * @author kal bugrara
 */
public class OrderItem implements Serializable {

    SolutionOffer solution;
    int quantity;

    public OrderItem() {
    }

    public OrderItem(SolutionOffer solution, int quantity) {
        this.solution = solution;
        this.quantity = quantity;
    }

    public int obtainOrderItemTotal() {
        return solution.getPrice() * quantity;
    }

    //The following calculates what the price gain would have been if products were sold at target price
    public int obtainOrderItemTargetTotal() {
        int targetTotal = 0;
        for (Product product : solution.getProducts()) {
            targetTotal += product.getTargetPrice() * quantity;
        }
        return targetTotal;
    }

    //returns positive if seller is making higher margin than target
    //returns negative if seller is making lower margin than target
    //otherwise zero meaning neutral
    public int calculatePricePerformance() {
        int pricePerfromance = 0;
        for (Product product : solution.getProducts()) {
            pricePerfromance += (solution.getPrice() - product.getTargetPrice()) * quantity;
        }
        return pricePerfromance;
    }

    public boolean isActualAboveTarget() {
        boolean result = true;
        for (Product product : solution.getProducts()) {
            if (solution.getPrice() < product.getTargetPrice()) {
                return false;
            }
        }
        return result;
    }

    public void printItemDetails() {
        System.out.println("OrderItem{" +
                "solution=" + solution +
                ", quantity=" + quantity +
                '}');
    }

    @Override
    public String toString() {
        return "OrderItem{" +
                "solution=" + solution +
                ", quantity=" + quantity +
                '}';
    }
}
