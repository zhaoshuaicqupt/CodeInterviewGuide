/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.OrderManagement;

import java.io.Serializable;

/**
 * @author kal bugrara
 */
public class OrderSummary implements Serializable {

    int salesvolume;
    boolean totalabovetarget;
    int orderpriceperformance;
    int numberofOrderitemsabovetarget;

    public OrderSummary(Order o) {
        salesvolume = o.obtainOrderTotal();
        totalabovetarget = o.isOrderAboveTotalTarget();
        orderpriceperformance = o.obtainOrderPricePerformance();
        numberofOrderitemsabovetarget = o.obtainNumberOfOrderItemsAboveTarget();

    }

    public int getOrderProfit() {
        return 0; // to be implemented
    }

    @Override
    public String toString() {
        return "OrderSummary{" +
                "salesvolume=" + salesvolume +
                ", totalabovetarget=" + totalabovetarget +
                ", orderpriceperformance=" + orderpriceperformance +
                ", numberofOrderitemsabovetarget=" + numberofOrderitemsabovetarget +
                '}';
    }
}
