/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.OrderManagement;

import digitalmarketing.CustomerManagement.CustomerProfile;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author kal bugrara
 */
public class MasterOrderList implements Serializable {
    ArrayList<Order> orders;
    MasterOrderReport masterorderreport;

    public MasterOrderList() {
        orders = new ArrayList();
    }

    public Order newOrder(CustomerProfile cp) {
        Order o = new Order(cp);
        orders.add(o);
        return o;

    }

    public MasterOrderReport generateMasterOrderReport() {
        masterorderreport = new MasterOrderReport();

        return masterorderreport;

    }

    public int obtainSalesVolume() {

        int sum = 0;
        for (Order order : orders) {
            sum = sum + order.obtainOrderTotal();
        }
        return sum;
    }

    public void printOrders() {
        System.out.println("Order List:");
        for (Order o : orders) {
            o.printOrderDetails();
        }
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }

    public void setOrders(ArrayList<Order> orders) {
        this.orders = orders;
    }

    public MasterOrderReport getMasterorderreport() {
        return masterorderreport;
    }

    public void setMasterorderreport(MasterOrderReport masterorderreport) {
        this.masterorderreport = masterorderreport;
    }

    @Override
    public String toString() {
        return "MasterOrderList{" +
                "orders=" + orders +
                ", masterorderreport=" + masterorderreport +
                '}';
    }
}
