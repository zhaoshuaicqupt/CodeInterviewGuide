/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.CustomerManagement;

import digitalmarketing.OrderManagement.Order;

import java.io.Serializable;

/**
 * @author kal bugrara
 */
public class CustomerSummary implements Serializable {
    Order subjectorder;
    int ordertotal;

    public CustomerSummary(CustomerProfile cp) {

    }

    @Override
    public String toString() {
        return "CustomerSummary{" +
                "subjectorder=" + subjectorder +
                ", ordertotal=" + ordertotal +
                '}';
    }
}
