package digitalmarketing.CustomerManagement;


import java.io.Serializable;

public enum CustomerType implements Serializable {
    /**
     * education discount: 0.7
     * enterprise discount: 0.8
     * personal : no discount
     */
    EDUCATION("education", 0.7), PERSIONAL("personal", 1), ENTERPRISE("enterprise", 0.9);

    private String type;
    private double discount;

    CustomerType() {
    }

    CustomerType(String type, double discount) {
        this.type = type;
        this.discount = discount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    @Override
    public String toString() {
        return "CustomerType{" +
                "type='" + type + '\'' +
                ", discount=" + discount +
                '}';
    }
}
