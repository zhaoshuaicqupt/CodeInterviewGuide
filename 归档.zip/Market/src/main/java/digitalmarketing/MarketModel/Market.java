/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.MarketModel;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author kal bugrara
 */
public class Market implements Serializable {
    ArrayList<MarketChannelAssignment> channels;
    MarketType marketType;
    String characteristic;

    public Market(String s, MarketType type) {
        this.characteristic = s;
        this.marketType = type;
        this.channels = new ArrayList<>();
    }

    /**
     * Add channels to the market
     *
     * @param channel
     */
    public void addChannel(Channel channel) {
        MarketChannelAssignment marketChannelAssignment = new MarketChannelAssignment(this, channel);
        channels.add(marketChannelAssignment);
    }

    public ArrayList<MarketChannelAssignment> getChannels() {
        return channels;
    }

    public void setChannels(ArrayList<MarketChannelAssignment> channels) {
        this.channels = channels;
    }

    public MarketType getMarketType() {
        return marketType;
    }

    public void setMarketType(MarketType marketType) {
        this.marketType = marketType;
    }

    public String getCharacteristic() {
        return characteristic;
    }

    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

    @Override
    public String toString() {
        return "Market{" +
                "channels=" + channels +
                ", marketType=" + marketType +
                ", characteristic='" + characteristic + '\'' +
                '}';
    }
}
