package digitalmarketing.MarketModel;

import java.io.Serializable;

/**
 * China discount :1
 * America discount 1.3
 * Englang discount 1.5
 */

public enum MarketType implements Serializable {

    CHINA("China", 1),
    AMERICA("America", 1.3),
    ENGLAND("England", 1.5);
    private String marketName;
    private double marketDiscount;

    MarketType() {
    }

    MarketType(String marketName, double marketDiscount) {
        this.marketName = marketName;
        this.marketDiscount = marketDiscount;
    }

    public String getMarketName() {
        return marketName;
    }

    public void setMarketName(String marketName) {
        this.marketName = marketName;
    }

    public double getMarketDiscount() {
        return marketDiscount;
    }

    public void setMarketDiscount(double marketDiscount) {
        this.marketDiscount = marketDiscount;
    }

    @Override
    public String toString() {
        return "MarketType{" +
                "marketName='" + marketName + '\'' +
                ", marketDiscount=" + marketDiscount +
                '}';
    }
}
