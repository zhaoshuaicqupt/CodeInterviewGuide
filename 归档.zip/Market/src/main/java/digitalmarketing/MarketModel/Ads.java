package digitalmarketing.MarketModel;

import java.io.Serializable;

public class Ads implements Serializable {

    private String adsDesc;
    private int adsCost;

    public Ads(String adsDesc, int adsCost) {
        this.adsDesc = adsDesc;
        this.adsCost = adsCost;
    }

    public String getAdsDesc() {
        return adsDesc;
    }

    public void setAdsDesc(String adsDesc) {
        this.adsDesc = adsDesc;
    }

    public int getAdsCost() {
        return adsCost;
    }

    public void setAdsCost(int adsCost) {
        this.adsCost = adsCost;
    }

    @Override
    public String toString() {
        return "Ads{" +
                "adsDesc='" + adsDesc + '\'' +
                ", adsCost=" + adsCost +
                '}';
    }
}
