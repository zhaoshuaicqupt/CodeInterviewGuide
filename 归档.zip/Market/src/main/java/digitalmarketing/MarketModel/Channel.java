/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarketing.MarketModel;

import java.io.Serializable;
import java.util.List;

/**
 * @author kal bugrara
 */
public class Channel implements Serializable {
    private String channelName;
    private double channelDiscount;
    private List<Ads> adsList;


    public Channel(String channelName, double channelDiscount, List<Ads> adsList) {
        this.channelName = channelName;
        this.channelDiscount = channelDiscount;
        this.adsList = adsList;
    }

    /**
     * Get all the advertising investment in the channel
     *
     * @return
     */
    public int obtainSumAdsCost() {
        int adsCostSum = 0;
        for (Ads ads : adsList) {
            adsCostSum += ads.getAdsCost();
        }
        return adsCostSum;
    }


    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public double getChannelDiscount() {
        return channelDiscount;
    }

    public void setChannelDiscount(double channelDiscount) {
        this.channelDiscount = channelDiscount;
    }

    public List<Ads> getAdsList() {
        return adsList;
    }

    public void setAdsList(List<Ads> adsList) {
        this.adsList = adsList;
    }

    @Override
    public String toString() {
        return "Channel{" +
                "channelName='" + channelName + '\'' +
                ", channelDiscount=" + channelDiscount +
                ", adsList=" + adsList +
                '}';
    }
}
